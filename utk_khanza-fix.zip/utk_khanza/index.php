<?php
    include"lib/koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="asset/css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body>
  
    <?php 
        include"modul/navbar.php";
    ?>

<?php 
    $page = isset($_GET['page'])?$_GET['page']:"";
  switch ($page) {
    case 'home':
      include "modul/home.php";
      break;
    case 'product':
      include "modul/product.php";
      break;
    case 'contact':
      include "modul/contact.php";
      break;
    case 'login':
      include "modul/login.php";
      break;
    case 'logout':
      include "modul/logout.php";
      break;
    case 'cekot':
      include "modul/checkout.php";
      break;
    case 'register':
      include "modul/register.php";
      break;
    case 'profil':
      include "modul/profil.php";
      break;
    case 'cekotsukses':
      include "modul/checkout_sukses.php";
      break;
        
    default:
    case 'home':
      include "modul/home.php";
      break;
      break;
  }
  ?>
   
   <footer class="footer">
  <div class="footer-container">
    <div class="footer-brand">
      <h2>PicoToys</h2>
      <p>Toko mainan terpercaya untuk buah hati tercinta. Temukan kebahagiaan dalam setiap mainan!</p>
    </div>
    <div class="footer-links">
      <h4>Menu</h4>
      <ul>
        <li><a href="?page=home">Home</a></li>
        <li><a href="?page=product">Shop</a></li>
        <li><a href="?page=contact">Contact Us</a></li>
      </ul>
    </div>
    <div class="footer-contact">
      <h4>Hubungi Kami</h4>
      <p>Email: support@picotoys.com</p>
      <p>WA: 0812-3456-7890</p>
      <p>Alamat: langit ketujuh rt 02 rw 012</p>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; 2025 PicoToys. All rights reserved.</p>
  </div>
</footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
