<div class="container py-5 mt-5">
  <h2 class="text-center mb-4">Produk Kami</h2>
  <div class="row row-cols-1 row-cols-md-3 g-4">

<?php
// Ambil data dari tb_product
$stmt = $conn->prepare("SELECT id_product, nama_product, deskripsi, harga, gambar FROM tb_product");
$stmt->execute();
$produk = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

    <?php 
    foreach ($produk as $row): 
    ?>
      <div class="col-md-4 mb-4">
        <div class="card h-100 shadow-sm card-hover">
        <img src="gbrproject/<?= htmlspecialchars($row['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($row['nama_product']) ?>" style="height: 350px; object-fit: cover;">
        <div class="card-body">
          <h5 class="card-title"><?= htmlspecialchars($row['nama_product']) ?></h5>
          <p class="card-text"><?= htmlspecialchars($row['deskripsi']) ?></p>
        </div>
        <div class="card-footer">
        <div class="d-flex justify-content-between fw-bold mt-3">
          <p class="text-primary">Rp <?=number_format($row['harga'], 0, ',', '.') ?>
        </p>
        <button 
            class="btn btn-outline-primary btn-sm" 
            data-bs-toggle="modal" 
            data-bs-target="#checkoutModal"
            data-nama="<?= htmlspecialchars($row['nama_product']) ?>"
            data-gambar="gbrproject/<?= htmlspecialchars($row['gambar']) ?>"
            data-harga="<?=$row['harga']?>">Beli Sekarang</button>
        </div>

        </div>
        
      </div>
    </div>

    <?php 
  endforeach; 
  ?>
</div>
</div> 

<style>
  .card-hover {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card-hover:hover {
  transform: translateY(-10px) scale(1.01);
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
  z-index: 2;
}
</style>
  

<!-- Modal Checkout -->
<div class="modal fade" id="checkoutModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Checkout Produk</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="?page=cekot" method="post">
        <div class="modal-body">
          <div class="row">
            <!-- Gambar Produk -->
            <div class="col-md-6 text-center mb-3">
              <img src="" id="gambarProduk" class="img-fluid rounded shadow" alt="Gambar Produk">
            </div>

            <!-- Form Isian -->
            <div class="col-md-6">
              <input type="hidden" name="hargaProduk" id="hargaProduk">
              <input type="hidden" name="nama_produk" id="namaProduk">
              
              
              <div class="mb-3">
                <label>Nama Penerima</label>
                <input type="text" name="nama" class="form-control" required>
              </div>
              
              <div class="mb-3">
                <label>Nomor Telepon</label>
                <input type="tel" name="telepon" class="form-control" required>
              </div>
              
              <div class="mb-3">
                <label>Alamat Pengiriman</label>
                <textarea name="alamat" class="form-control" rows="2" required></textarea>
              </div>
              
              <div class="row align-items-center mb-3">
                <div class="col-auto">
                    <label class="col-form-label me-5">Jumlah</label>
                </div>
                <div class="col">
                  <div class="d-flex align-items-center gap-3">
                    <span class="fs-4" style="cursor: pointer;" onclick="ubahJumlah(-1)">-</span>
                    <input type="number" name="jumlah" id="jumlah" class="form-control text-center" value="1" min="1" style="width: 70px;" required>
                    <span class="fs-4" style="cursor: pointer;" onclick="ubahJumlah(1)">+</button>
                </div>
              </div>
            </div>

              <div class="mb-3">
                <label>Metode Pembayaran</label>
                <select name="metode_pembayaran" class="form-select" required>
                  <option value="">Pilih Metode</option>
                  <option value="Transfer Bank">Transfer Bank</option>
                  <option value="COD">Cash on Delivery (COD)</option>
                  <option value="E-Wallet">E-Wallet (Dana, OVO, dll)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer d-flex justify-content-between align-items-center">
          <div class="fw-bold text-primary">
            Total: <span id="totalHargaTeks">Rp 0</span>
        </div>
          <div>
    <a href="?page=cekot"><button type="submit" class="btn btn-primary fw-bold shadow">Checkout</button></a>
  </div>
</div>
      </form>
      <style>
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
}

        input[type=number] {
        -moz-appearance: textfield; 
}
      </style>
    </div>
  </div>
</div>


<script>
const modal = document.getElementById('checkoutModal');
modal.addEventListener('show.bs.modal', function (event) {
  const button = event.relatedTarget;
  const nama = button.getAttribute('data-nama');
  const gambar = button.getAttribute('data-gambar');
  const harga = parseInt(button.getAttribute('data-harga'));

  modal.querySelector('#namaProduk').value = nama;
  modal.querySelector('#gambarProduk').src = gambar;
  modal.querySelector('#hargaProduk').value = harga;
  modal.querySelector('input[name="jumlah"]').value = 1;

  updateTotal(harga, 1); // default hitung total saat buka modal
});

// Fungsi update total harga
function updateTotal(harga, jumlah) {
  const total = harga * jumlah;
  document.getElementById('totalHargaTeks').textContent = total.toLocaleString('id-ID', {
    style: 'currency',
    currency: 'IDR'
  });
}

// Saat jumlah diubah, total langsung berubah
document.addEventListener('input', function () {
  const harga = parseInt(document.getElementById('hargaProduk').value || 0);
  const jumlah = parseInt(document.querySelector('input[name="jumlah"]').value || 0);
  updateTotal(harga, jumlah);
});

function ubahJumlah(change) {
  const jumlahInput = document.getElementById('jumlah');
  let jumlah = parseInt(jumlahInput.value);
  if (isNaN(jumlah)) jumlah = 1;

  jumlah = Math.max(1, jumlah + change); // Biar gak bisa kurang dari 1
  jumlahInput.value = jumlah;

  const harga = parseInt(document.getElementById('hargaProduk').value || 0);
  updateTotal(harga, jumlah);
}

</script>

<style>
    body{
        background: linear-gradient(to bottom right, rgb(208, 245, 250), rgb(250, 204, 218));
    }
</style>
