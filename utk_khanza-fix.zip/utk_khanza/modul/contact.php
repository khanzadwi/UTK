<?php
if (isset($_POST['kirim'])) {
    $nama   = $_POST['nama'];
    $email  = $_POST['email'];
    $subjek = $_POST['subjek'];
    $pesan  = $_POST['pesan'];

    // Sesuaikan dengan nama kolom tabel kamu
    $sql = $conn->prepare("INSERT INTO tb_contact (nama, email, subjek, pesan) VALUES (:nama, :email, :subjek, :pesan)");
    $sql->bindParam(':nama', $nama);
    $sql->bindParam(':email', $email);
    $sql->bindParam(':subjek', $subjek);
    $sql->bindParam(':pesan', $pesan);

    if ($sql->execute()) {
        echo "";
    } else {
        echo "";
    }
}
?>

<section class="contact-section mt-5">
  <div class="contact-wrapper">
    <div class="contact-info">
      <h2>Contact Information</h2><br>
      <p><strong>Alamat:</strong> Jl. Mainan Ceria No. 123, Jakarta</p><br>
      <p><strong>WhatsApp:</strong> 0812-3456-7890</p><br>
      <p><strong>Email:</strong> info@picotoys.com</p><br>
      <p><strong>Jam Operasional:</strong> Senin - Sabtu, 09.00 - 18.00</p><br>
      <p><strong>Instagram:</strong> @picotoys.id</p><br>
      <p><strong>TikTok:</strong> @picotoys</p>
    </div>

    <div class="contact-form">
      <h2>Kirim Pesan</h2>
      <form action="" method="POST">
        <input type="text" name="nama" placeholder="Nama Kamu" required>
        <input type="email" name="email" placeholder="Email Kamu" required>
        <input type="text" name="subjek" placeholder="Subjek" required>
        <textarea name="pesan" rows="5" placeholder="Tulis pesan kamu di sini..." required></textarea>
        <button type="submit" name="kirim">Kirim</button>
      </form>
    </div>
  </div>

  <div class="map-container">
    <iframe 
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1983.7417232581978!2d106.827153!3d-6.175110!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3e1f29b6455%3A0x37e9c79fcd3b46fd!2sMonas!5e0!3m2!1sen!2sid!4v1615190599374!5m2!1sen!2sid" 
      width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy">
    </iframe>
  </div>
</section>

<style>
  .contact-section {
    background: linear-gradient(to bottom right, rgb(208, 245, 250), rgb(250, 204, 218));
    padding: 60px 20px;
    text-align: center;
  }

  .contact-wrapper {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 40px;
    margin-bottom: 40px;
  }

  .contact-info, .contact-form {
    background: white;
    border-radius: 12px;
    padding: 30px;
    max-width: 400px;
    flex: 1;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    text-align: left;
  }

  .contact-info h2, .contact-form h2 {
    color: ;
    margin-bottom: 20px;
  }

  .contact-info p {
    color: #444;
    line-height: 1.6;
    margin: 10px 0;
  }

  .contact-form input,
  .contact-form textarea {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 8px;
    border: 1px solid #ccc;
  }

  .contact-form button {
    padding: 12px 25px;
    background: #4b3fff;
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
    transition: 0.3s;
  }

  .contact-form button:hover {
    background: #372fdc;
  }

  .map-container iframe {
    width: 100%;
    height: 400px;
    border: 0;
    border-radius: 12px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  }
</style>