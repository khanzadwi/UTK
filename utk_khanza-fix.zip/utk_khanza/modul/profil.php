<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'lib/koneksi.php';

if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id_user'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user']['id_user'];
$stmt = $conn->prepare("SELECT * FROM tb_user WHERE id_user = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-5 pt-4">
  <!-- Profil Card -->
<div class="card shadow p-4 mb-4 mt-4 position-relative" style="min-height: 450px;">
  <!-- Tombol Logout di pojok kanan atas -->
  <a href="?page=logout" class="btn btn-danger position-absolute end-0 top-0 m-3">
    <i class="fas fa-sign-out-alt me-1"></i> Logout</a>

  <!-- Tombol Riwayat Pesanan di pojok kanan bawah -->
  <a href="" class="btn btn-outline-dark position-absolute end-0 bottom-0 m-3">
    <i class="fas fa-history me-1"></i> Riwayat Pesanan</a>

  <div class="row">
    <!-- Kolom Gambar & Edit -->
    <div class="col-md-3 text-center">
      <i class="fas fa-user-circle fa-10x text-secondary"></i>
      <a href="" class="btn text-primary mt-1 w-100">
        <i class="fas fa-edit me-1"></i> Edit Profil</a>
    </div>

    <!-- Kolom Data -->
    <div class="col-md-9">
      <h4 class="mb-3">Profil Saya</h4><br>
      <p><strong>Nama:</strong> <?= htmlspecialchars($user['nama_user']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
      <p><strong>Tanggal Daftar:</strong> <?= date('d M Y, H:i', strtotime($user['created_at'])) ?></p>
    </div>
  </div><br>

  <!-- Ikon Status Pesanan -->
  <div class="row text-center mt-4">
    <div class="col">
      <a href="?status=menunggu" class="text-decoration-none text-dark">
        <i class="fas fa-clock fa-2x"></i><br>
        <small>Menunggu</small>
      </a>
    </div>
    <div class="col">
      <a href="?status=diproses" class="text-decoration-none text-dark">
        <i class="fas fa-box-open fa-2x"></i><br>
        <small>Diproses</small>
      </a>
    </div>
    <div class="col">
      <a href="?status=dikirim" class="text-decoration-none text-dark">
        <i class="fas fa-shipping-fast fa-2x"></i><br>
        <small>Dikirim</small>
      </a>
    </div>
    <div class="col">
      <a href="?status=selesai" class="text-decoration-none text-dark">
        <i class="fas fa-check-circle fa-2x"></i><br>
        <small>Selesai</small>
      </a>
    </div>
  </div>
  <br>
</div>
</div>
<style>
  body {
    background: linear-gradient(to bottom right, rgb(208, 245, 250), rgb(250, 204, 218));
  }
</style>