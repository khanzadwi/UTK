<meta name="viewport" content="width=device-width, initial-scale=1.0">
<section class="hero mt-5">
  <div class="hero-text">
    <h1>Find the best<br><span class="highlight">Toys for your Children</span></h1>
    <p>We deliver a curated selection of fantastic, hand-picked, age appropriate toys books and puzzles, straight to your door.</p>
    <div class="hero-buttons">
      <a href="?page=product" class="btn primary">Get Started</a>
    </div>
  </div>
  <div class="hero-image ">
    <img src="asset/img/16.png" alt="Clown Toy Box" >
  </div>
</section>


<div class="promo-section mt-4">
    <div class="promo left">
      <img src="asset/img/3.png" alt="anak perempuan" />
      <div class="promo-content">
        <h2>Fun Deals for Kids</h2>
        <p>Special discounts on favorite toys and cuddly friends!</p>
      </div>
    </div>
    <div class="promo right">
      <img src="asset/img/8.png" alt="anak laki laki" />
      <div class="promo-content">
        <h2>Top Toy Picks</h2>
        <p>Check out this week's most popular and fun toys!</p>
      </div>
    </div>
  </div>

<div class="mt-4">
<section style="background: #92cfdc; color: white; padding: 50px 20px;">
  <div style="max-width: 1200px; margin: 0 auto; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between;">
    <div style="flex: 1; min-width: 300px; padding: 20px;">
      <h2 style="font-size: 2em; font-weight: bold;">Mainan Edukatif dan Kreatif Terbaru di PicoToys</h2>
      <p style="margin: 20px 0; font-size: 1.1em; line-height: 1.6;">
        Di PicoToys, kami menghadirkan koleksi mainan edukatif terbaru yang dirancang khusus untuk membantu tumbuh kembang anak Anda secara optimal. 
        Temukan berbagai mainan interaktif seperti balok susun, boneka karakter lucu, mainan suara, dan alat musik mini yang bisa mengasah kreativitas dan motorik anak sejak dini. 
        Didesain aman, ramah anak, dan menyenangkan, semua produk kami siap menjadikan waktu bermain si kecil lebih seru dan bermakna!
      </p>
    </div>
    <div style="flex: 1; min-width: 300px; padding: 20px; text-align: center;">
      <img src="asset/img/18.png" alt="Boneka Mainan Anak" style="max-width: 80%; height: auto;">
    </div>
  </div>
</section>

<section class="explore-section mt-4">
  <div class="container">
    <h2>Explore, Excite & Inspire!</h2>
    <div class="features">
      <div class="feature">
        <img src="asset/img/22.jpeg" alt="Playland Icon" />
        <h3>Play & Learn Toys</h3>
        <p>Fun and educational toys that help kids learn and grow through play!</p>
      </div>
      <div class="feature">
        <img src="asset/img/21.jpeg" alt="Birthday Icon" />
        <h3>Gift Ideas</h3>
        <p>Top toy picks for birthdays and special surprises they’ll love!</p>
      </div>
      <div class="feature">
        <img src="asset/img/20.jpeg" alt="Childcare Icon" />
        <h3>New Arrivals</h3>
        <p>Discover the latest and most exciting toys for endless fun!</p>
      </div>
    </div>
  </div>
</section>
<br>