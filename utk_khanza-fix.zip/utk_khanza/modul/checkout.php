<?php
include 'lib/koneksi.php';

if (!isset($_SESSION['user'])) {
    // Stop eksekusi kalau belum login
    $_SESSION['show_login_modal'] = true;
    header("location: ?page=home");
    echo "<script>window.location.href='index.php';</script>";
    exit;
}

// Ambil data dari form
$nama_pemesan = $_POST['nama'];
$telepon = $_POST['telepon'];
$alamat = $_POST['alamat'];
$nama_produk = $_POST['nama_produk'];
$jumlah = $_POST['jumlah'];
$metode = $_POST['metode_pembayaran'];
$harga_satuan = $_POST['hargaProduk']; // pastikan input hidden ini ada
$total = $harga_satuan * $jumlah;

// Simpan ke database
$stmt = $conn->prepare("INSERT INTO tb_pesanan 
(id_user, nama_pemesan, telepon, alamat, produk, jumlah, total_harga, metode_pembayaran, status) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->execute([
  $_SESSION['user']['id_user'],
  $nama_pemesan, 
  $telepon,
  $alamat,
  $nama_produk,
  $jumlah,
  $total,
  $metode,
  $status
]);

// Redirect ke halaman sukses atau tampilkan pesan
 echo "<script>window.location.href=' ?page=cekotsukses';</script>";
?>

