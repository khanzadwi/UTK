-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2025 at 08:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbpico_toys`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `tb_contact`
--

CREATE TABLE `tb_contact` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subjek` varchar(150) NOT NULL,
  `pesan` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_contact`
--

INSERT INTO `tb_contact` (`id_user`, `nama`, `email`, `subjek`, `pesan`, `tanggal`) VALUES
(1, 'popo', 'poposiloyo@gmail.com', 'popooo', 'siloyoooo', '2025-05-06 15:08:39'),
(2, 'dini', 'miko@gmail.com', 'haloo', 'haaaiiii', '2025-05-07 03:23:12'),
(3, 'apip', 'apip@gmail.com', 'apipah', 'pipipi', '2025-05-09 02:35:58'),
(4, 'khanza', 'khanza@gmail.com', 'bla bla bla', 'barangnya bagus bnget kak, anak aku bahagia bnget \r\n', '2025-05-13 08:08:38'),
(5, 'dini', 'khanzaloplop@gmail.com', 'www', 'maianannya jelek kya yang jual', '2025-05-15 04:20:19');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pesanan`
--

CREATE TABLE `tb_pesanan` (
  `id` int(11) NOT NULL,
  `nama_pemesan` varchar(100) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `produk` varchar(100) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total_harga` decimal(10,2) DEFAULT NULL,
  `metode_pembayaran` enum('Transfer Bank','COD','E-Wallet') NOT NULL,
  `status` enum('Menunggu','Diproses','Dikirim','Selesai') DEFAULT 'Menunggu',
  `tanggal_pesan` datetime DEFAULT current_timestamp(),
  `id_user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_pesanan`
--

INSERT INTO `tb_pesanan` (`id`, `nama_pemesan`, `telepon`, `alamat`, `produk`, `jumlah`, `total_harga`, `metode_pembayaran`, `status`, `tanggal_pesan`, `id_user`) VALUES
(1, 'ilham', '089876543212', 'kebon kopi yang ada kopi liongnya', 'LEGO DUPLO Town Farm Animal', 2, 520000.00, 'COD', '', '2025-05-10 20:25:03', NULL),
(2, 'duni', '12345567', 'abcdefghijklmnopqrstuvwxyz', 'Barbie Dreamhouse Playset', 1, 1200000.00, 'E-Wallet', '', '2025-05-10 20:50:31', NULL),
(3, 'bu ibu', '089787655564', 'kolong jembatan ramayana', 'LEGO DUPLO Town Farm Animal', 2, 520000.00, 'Transfer Bank', '', '2025-05-10 21:46:38', NULL),
(6, 'ayah arra', '08965333223', 'depan rumah pak rt 2, rw 12', 'LEGO DUPLO Town Farm Animal', 2, 520000.00, 'Transfer Bank', '', '2025-05-11 20:45:09', NULL),
(7, 'popo', '089687141519', 'langit ketujuh', 'LOL Surprise OMG Fashion Doll', 1, 380000.00, 'COD', '', '2025-05-12 10:34:21', NULL),
(8, 'adit', '24589742', 'ytsuhwgxjs', 'LEGO DUPLO Town Farm Animal', 3, 780000.00, 'COD', '', '2025-05-12 12:41:06', NULL),
(9, 'zahra', '0897876665566', 'belakang gm', 'Smart Globe Talking Atlas', 1, 1100000.00, 'Transfer Bank', '', '2025-05-14 02:52:52', NULL),
(10, 'july', '4568764787', 'madura belakang fly over', 'LEGO Classic Creative Brick Box', 3, 900000.00, 'COD', '', '2025-05-14 02:54:15', NULL),
(11, 'khanza', '0895345188818', 'depan rumah pak rt', 'LEGO DUPLO Town Farm Animal', 2, 520000.00, 'Transfer Bank', '', '2025-05-14 13:27:03', NULL),
(12, 'dini', '087765432', 'lorem', 'Vespa Mainan Aki untuk Anak', 1, 2300000.00, 'COD', '', '2025-05-14 14:52:30', NULL),
(13, 'katanya mah aku', '080788775421', 'dibawah naungan gm', 'LEGO DUPLO Town Farm Animal', 1, 260000.00, 'E-Wallet', '', '2025-05-14 19:44:25', NULL),
(14, 'dini', '089876543212', 'thoyyibah', 'Hape Grand Piano Mainan Anak', 1, 1750000.00, 'Transfer Bank', '', '2025-05-14 19:52:51', NULL),
(15, 'khanza', '0895345188818', 'gang ampel', 'Fisher-Price Laugh & Learn Smart Stages Puppy', 1, 375000.00, 'E-Wallet', NULL, '2025-05-15 01:29:58', 4),
(16, 'siti', '0897', 'gang dukuh', 'Kitchen Set Anak Mini Kompor & Peralatan', 1, 170000.00, 'E-Wallet', NULL, '2025-05-16 08:31:40', 6),
(17, 'atul', '089765234451', 'gang tapos', 'LEGO DUPLO Town Farm Animal', 1, 260000.00, 'COD', NULL, '2025-05-20 11:15:18', 17);

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE `tb_product` (
  `id_product` int(11) NOT NULL,
  `nama_product` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`id_product`, `nama_product`, `deskripsi`, `harga`, `gambar`) VALUES
(7, 'LEGO Classic Creative Brick Box', 'Set Lego warna-warni untuk kreativitas tanpa batas.', 300000, 'lego classic.jpg'),
(8, 'LEGO DUPLO Town Farm Animal', 'Blok ukuran besar, cocok untuk balita belajar tentang hewan ternak.', 260000, 'lego duplo.jpg'),
(9, 'Mega Blocks First Builders', 'Blok besar dan ringan, ideal untuk anak 1-3 tahun.', 180000, 'mega blocks.jpg'),
(10, 'Magformers  Magnetic Set', 'Blok magnetik edukatif yang bisa membentuk berbagai bangunan dan objek 3D.\r\n', 550000, 'magformers.jpg'),
(11, 'Hot Wheels Ultimate Garage', 'Track mobil bertingkat dengan lift otomatis.', 500000, 'Hot Wheels - Pista para coches de juguete surtido Garaje Hot Wheels City Mattel.jpg'),
(12, 'Barbie Dreamhouse Playset', 'Rumah boneka 3 lantai lengkap dengan furnitur dan lift.', 1200000, 'Barbie Dreamhouse Pool Party Doll House and Playset with 75+ Pieces, 45 in, Slide & Puppy Elevator - Walmart_com.jpg'),
(13, 'NERF Elite Disruptor Blaster', 'Mainan tembak dart busa, cocok untuk permainan aksi.', 230000, 'Wajib Coba Nerf Disruptor Original Hasbro.jpg'),
(14, 'LOL Surprise OMG Fashion Doll', 'Boneka kejutan dengan baju dan aksesori super modis.', 380000, 'LOL Surprise_ OMG Fashion House.jpg'),
(15, 'Tamiya Mini 4WD Original Series', 'Mobil balap mini legendaris yang bisa dirakit sendiri.', 150000, 'Tamiya Wild Mini 4wd Series No_03 Lunch Box Junior Model Kit 17003 Japan.jpg'),
(16, 'Kitchen Set Anak Mini Kompor & Peralatan', 'Mainan masak-masakan dengan suara & lampu.', 170000, 'Kids Kitchen Play Cooking Set - Colourful.jpg'),
(17, 'Transformers Optimus Prime Figure', 'Mainan robot yang bisa berubah bentuk, favorit sepanjang masa.', 450000, 'Transformers Power Flip Optimus Prime.jpg'),
(18, 'Disney Princess Royal Shimmer Doll', 'Boneka putri dari karakter Disney lengkap dengan gaun elegan.', 200000, 'Disney Princess Royal Collection - all 12 Royal Shimmer dolls in one playset.jpg'),
(19, 'VTech Touch and Learn Activity Desk', 'Meja edukatif interaktif dengan banyak fitur belajar.', 800000, 'Kids Activity Desk on Amazon.jpg'),
(20, 'Puzzle Kayu Alfabet & Angka', 'Puzzle edukasi untuk belajar huruf dan angka.', 75000, '9cc540d8ed86b9fdeb4b69cbc8b442cf-removebg-preview.png'),
(21, 'LeapFrog Learn & Groove Musical Table', 'Meja musik interaktif untuk belajar bentuk, warna, dan bunyi.', 500000, 'LeapFrog Learn and Groove Musical Table (Frustration Free Packaging), Pink.jpg'),
(22, 'Smart Globe Talking Atlas', 'Globe pintar yang bisa bicara dan mengenalkan geografi dunia.', 1100000, 'Educational Insights Geosafari Jr_ Talking Globe.jpg'),
(23, 'Fisher-Price Baby\'s First Blocks', 'Blok warna-warni dengan bentuk dasar (bulat, kotak, segitiga). Melatih motorik halus dan mengenal bentuk.', 160000, 'd044f3f263a50ca2ca1128ee2236d27d-removebg-preview.png'),
(24, 'Melissa & Doug Wooden Building Blocks Set', '100 blok kayu berkualitas tinggi dengan warna aman. Merangsang kreativitas dan keterampilan motorik.', 300000, 'Melissa & Doug.jpg'),
(25, 'B. Toys One Two Squeeze Blocks', 'Blok empuk dan bisa digigit, aman untuk bayi. Bisa disusun dan dipencet, mengeluarkan bunyi lucu.', 270000, '7b7961321a781e5dec6e27165bafd51b-removebg-preview.png'),
(26, 'LeapFrog Stack & Tumble Elephant', 'Mainan gajah interaktif untuk menyusun cincin blok, dilengkapi lagu dan cahaya. Cocok untuk bayi 6 bulan+.', 400000, 'download (4).jpg'),
(28, 'Fisher-Price Laugh & Learn Smart Stages Puppy', 'Boneka pintar interaktif yang bisa menyanyi, bicara, dan ngajarin anak huruf & angka. Seru, lucu, dan edukatif!\r\n', 375000, 'Fisher-Price Laugh & Learn Smart Stages Puppy _ JD Williams.jpeg'),
(29, 'VTech Sit-to-Stand Learning Walker', 'Baby walker interaktif dengan tombol, musik, dan lampu. Bantu bayi belajar jalan sambil main.', 575000, 'Buy VTech Stroll and Discover Activity Walker - English Edition for CAD 59_99 _ Toys R Us Canada.jpeg'),
(30, 'Play-Doh Kitchen Creations Set', 'Mainan lilin warna-warni untuk bikin makanan seru. Asah kreativitas dan motorik halus anak.', 190000, 'Play-Doh Little Chef Starter Playset.jpeg'),
(31, 'Little Tikes Cozy Coupe', 'Mobil-mobilan klasik yang bisa dikayuh anak sendiri. Awet, lucu, dan disukai sepanjang masa.', 1200000, 'Little Tikes - Estacion de Bomberos Let\'s Go Cozy Coupe.jpeg'),
(32, 'Skip Hop Activity Center 3-in-1', 'Meja aktivitas bayi premium: bisa diputar, lompat, jadi meja belajar. All-in-one buat perkambangan dini.', 2200000, 'Skip Hop Silver Lining Cloud Activity Center.jpeg'),
(33, 'Crayola Inspiration Art Case', 'Set mewarnai isi 140+ item: crayon, spidol, pensil warna. Cocok untuk anak kreatif pecinta seni.', 350000, 'Crayola Assorted Zigzag Inspiration Art Case, 140 Piece, Art Set for Kids - Walmart_com.jpeg'),
(34, 'Sylvanian Families Red Roof House Set', 'Rumah boneka super detail dengan karakter lucu dan perabot mini. Gemesin dan kolektibel banget!', 890000, 'Calico Critters Red Roof Grand Mansion Gift Set.jpeg'),
(35, 'Thomas & Friends TrackMaster Motorized Set', 'Kereta Thomas elektrik dengan rel seru. Cocok buat penggemar kereta dan petualangan.', 720000, 'Thomas & Friends Fisher-Price Trackmaster Motorized Railway Switchback Swamp Playset.jpeg'),
(36, 'Melissa & Doug Wooden Toy Kitchen', 'Dapur kayu mainan estetik dan lengkap, favorit anak-anak yang suka roleplay masak-masakan.', 1600000, 'Melissa & Doug Wooden Slice & Stack Sandwich Counter with Deli Slicer – 56-Piece Pretend Play Food Pieces.jpeg'),
(37, 'LeapFrog Scout\'s Learning Lights Remote', 'Remote mainan edukatif dengan lampu dan suara. Ajarin angka, warna, dan musik lewat tombol-tombol lucu, bikin anak betah belajar sambil main!', 285000, 'Leapfrog Scout\'s Learning Lights Remote Deluxe.jpeg'),
(38, 'Robot Mainan Cerdas Tobot Titan', 'Robot Korea Transformable, gabungan kendaraan jadi 1 robot besar. Mirip Transformers versi anak.', 490000, 'TOBOT Galaxy Detectives Muunneltava robotti Speed, 23 cm.jpeg'),
(39, 'Vespa Mainan Aki untuk Anak', 'Motor Vespa mini bisa dikendarai anak, dilengkapi lampu dan suara. Bergaya banget!', 2300000, 'download.jpeg'),
(40, 'Hape Grand Piano Mainan Anak', 'Piano kayu dengan 30 tuts, suara jernih & desain elegan. Cocok untuk anak berbakat musik.', 1750000, 'Hape Deluxe White Grand Piano Thirty Key Piano Toy.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama_user`, `email`, `password`, `created_at`) VALUES
(2, 'jihan alika otaya', 'jihannn@gmail.com', 'alika123', '2025-05-14 00:48:07'),
(3, 'dini khairani', 'dinicans@gmail.com', 'dini000', '2025-05-14 00:51:06'),
(4, 'khanza dwi andaro', 'khanzaloplop@gmail.com', 'loplop444', '2025-05-14 01:39:07'),
(5, 'popo', 'poposiloyo@gmail.com', 'popo000', '2025-05-14 02:02:07'),
(6, 'siti nur halisa', 'halisa@gmail.com', 'lisa12345', '2025-05-14 02:10:52'),
(7, 'ilham', 'ilhamgege@gmail.com', 'gege333', '2025-05-14 02:21:29'),
(8, 'zahraaa', 'zahra@gmail.com', 'zahra123', '2025-05-14 10:16:09'),
(9, 'muhammad ilham rafly', 'apihhh@gmail.com', 'ilham2025', '2025-05-16 08:42:58'),
(10, 'jaya', 'jaya@gmail.com', 'jaya123', '2025-05-16 08:44:30'),
(11, 'diniiiii', 'dinikhairani@gmail.com', 'dini000', '2025-05-16 08:48:20'),
(12, 'aku sayang kamu', 'akuuu@gmail.com', 'aku09876', '2025-05-16 09:44:19'),
(13, 'jahra', 'jahraa@gmail.com', 'jaya123', '2025-05-16 09:48:01'),
(14, 'sayur', 'sayurmayur12@gmail.com', 'sayuranenak', '2025-05-16 09:49:09'),
(15, 'yuyun', 'yuyun@gmail.com', '12345', '2025-05-16 09:55:13'),
(16, 'idaa', 'idaa@gmail.com', '00000', '2025-05-16 10:22:26'),
(17, 'juliatul', 'atul@gmail.com', 'atul111', '2025-05-20 11:11:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tb_contact`
--
ALTER TABLE `tb_contact`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_product`
--
ALTER TABLE `tb_product`
  ADD PRIMARY KEY (`id_product`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_contact`
--
ALTER TABLE `tb_contact`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tb_product`
--
ALTER TABLE `tb_product`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
