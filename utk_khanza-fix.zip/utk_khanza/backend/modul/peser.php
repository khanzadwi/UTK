<?php
$query = $conn->query("SELECT * FROM tb_contact ORDER BY id_user DESC");
?>

<h2 class="mb-5 mt-4 text-center">Daftar Pesan Pengguna</h2>
<div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead class="text-center table-primary">
            <tr>
              <th>No</th>
              <th>Nama</th>
              <th>Email</th>
              <th>Subjek</th>
              <th>Pesan</th>
              <th>Tanggal</th>
            </tr>
          </thead>
          <tbody>

  <?php
  $no = 1;
  while ($data = $query->fetch(PDO::FETCH_ASSOC)) {
  ?>
    <tr>
      <td><?= $no++; ?></td>
      <td><?= htmlspecialchars($data['nama']) ?></td>
      <td><?= htmlspecialchars($data['email']) ?></td>
      <td><?= htmlspecialchars($data['subjek']) ?></td>
      <td><?= htmlspecialchars($data['pesan']) ?></td>
      <td><?= $data['tanggal'] ?? '-' ?></td>
    </tr>
  <?php } ?>
</table>
