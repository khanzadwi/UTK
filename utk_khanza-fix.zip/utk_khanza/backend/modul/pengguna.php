<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../lib/koneksi.php';

$stmt = $conn->query("SELECT * FROM tb_user");
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-4">
  <h2 class="mb-4 text-center">Daftar Pengguna</h2><br>
  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
      <thead class="table-primary text-center">
  <tr>
    <th>No</th>
    <th>Nama</th>
    <th>Email</th>
    <th>Tanggal Daftar</th>
  </tr>
</thead>
<tbody>
  <?php $no = 1; foreach ($data as $row): ?>
  <tr>
    <td class="text-center"><?= $no++ ?></td>
    <td><?= htmlspecialchars($row['nama_user']) ?></td>
    <td><?= htmlspecialchars($row['email']) ?></td>
    <td><?= date('d M Y, H:i', strtotime($row['created_at'])) ?></td>
  </tr>
  <?php 
endforeach; 
?>
</tbody>
    </table>
  </div>
</div>