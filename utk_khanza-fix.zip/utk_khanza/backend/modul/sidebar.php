<div class="sidebar">
    <h2><i class="fas fa-cube"></i> PicoToys</h2>
    <a href="?page=con"><i class="fas fa-home"></i> Dashboard</a>
    <a href="?page=pro"><i class="fas fa-box"></i> Produk</a>
    <a href="?page=pesanan"><i class="fas fa-shopping-cart"></i> Pesanan</a>
    <a href="?page=user"><i class="fas fa-users"></i> Pengguna</a>
    <a href="?page=peser"><i class="fas fa-paper-plane"></i> Pesan User</a>
    <a href="?page=logout" style="color: #ffc107;"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>