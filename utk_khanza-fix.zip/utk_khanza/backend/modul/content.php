<?php
include "../lib/koneksi.php";

// hitung total produk
$stmt = $conn->query("SELECT COUNT(*) AS total_produk FROM tb_product");
$data = $stmt->fetch(PDO::FETCH_ASSOC);
$total_produk = $data['total_produk'];

$stmt = $conn->query("SELECT COUNT(*) AS total_pesanan FROM tb_pesanan");
$data = $stmt->fetch(PDO::FETCH_ASSOC);
$total_pesanan = $data['total_pesanan'];

$stmt = $conn->query("SELECT COUNT(*) AS total_pesan FROM tb_contact");
$data = $stmt->fetch(PDO::FETCH_ASSOC);
$total_pesan = $data['total_pesan'];

?>
   
   <h1>Selamat Datang, <?= $_SESSION['admin']; ?>!</h1>
    <div class="card-box">
        <div class="card">
            <h3>Total Produk</h3>
            <p><?= $total_produk ?> Produk</p>
        </div>
        <div class="card">
            <h3>Total Pesanan</h3>
            <p><?= $total_pesanan ?> Pesanan</p>
        </div>
        <div class="card">
            <h3>Total Pesan User</h3>
            <p><?= $total_pesan ?> Pesan</p>
        </div>
    </div>

    
