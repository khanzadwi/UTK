<h2 class="mb-4">Tambah Produk</h2>
<form method="POST" enctype="multipart/form-data">
  <div class="mb-3">
    <label for="nama" class="form-label">Nama Produk</label>
    <input type="text" class="form-control" id="nama" name="nama_produk" required>
  </div>

  <div class="mb-3">
    <label for="deskripsi" class="form-label">Deskripsi</label>
    <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required></textarea>
  </div>

  <div class="mb-3">
    <label for="harga" class="form-label">Harga</label>
    <input type="number" class="form-control" id="harga" name="harga" required>
  </div>

  <div class="mb-3">
    <label for="gambar" class="form-label">Gambar Produk</label>
    <input type="file" class="form-control" id="gambar" name="gbr">
  </div>

  <button type="submit" class="btn btn-primary" name="submit">Simpan Produk</button>
</form>

<?php
if(isset($_POST['submit'])){
    $nm = $_POST['nama_produk'];
    $desk = $_POST['deskripsi'];
    $hrga = $_POST['harga'];
    $gmbr = $_FILES['gbr']['name'];
    $path = '../gbrproject/';
    move_uploaded_file($_FILES['gbr']['tmp_name'],$path.$gmbr);
    $sqlinput = $conn->prepare('INSERT INTO tb_product(nama_product,deskripsi,harga,gambar)VALUES(:nama,:deskripsi,:harga,:gbr)');
    $sqlinput->bindParam(':nama', $nm);
    $sqlinput->bindParam(':deskripsi', $desk);
    $sqlinput->bindParam(':harga', $hrga);
    $sqlinput->bindParam(':gbr', $gmbr);
    if($sqlinput->execute()){
     header('location:?page=pro');
     exit;
    }else {
      echo "Gagal menambahkan product :" . $sqlinput->errorInfo()[2];
        }
      }
?>