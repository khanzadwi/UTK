<?php
    $id = $_GET['idpro'];
    $b = $conn->prepare("SELECT * FROM tb_product WHERE id_product = ?");
    $b->execute([$id]);
    $result = $b->fetch(PDO::FETCH_ASSOC);
?>

<form method="POST" enctype="multipart/form-data">
  <input type="hidden" name="id" value="<?= $result['id_product'] ?>">
  <div class="mb-3">
    <label for="nama" class="form-label">Nama Produk</label>
    <input type="text" class="form-control" id="nama" name="nama_produk" value="<?= $result['nama_product'] ?>" required>
  </div>

  <div class="mb-3">
    <label for="deskripsi" class="form-label">Deskripsi</label>
    <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required><?= $result['deskripsi'] ?></textarea>
  </div>

  <div class="mb-3">
    <label for="harga" class="form-label">Harga</label>
    <input type="number" class="form-control" id="harga" name="harga" value="<?= $result['harga'] ?>" required>
  </div>

  <div class="mb-3">
    <label for="gambar" class="form-label">Gambar Produk</label>
    <input type="file" class="form-control" id="gambar" name="gbr">
  </div>

  <button type="submit" class="btn btn-primary" name="submit">Update</button>
</form>

<?php
if (isset($_POST['submit'])) {
    $path = '../gbrproject/';
    $idp = $_POST['id'];
    $nma = $_POST['nama_produk'];
    $desk = $_POST['deskripsi'];
    $hrga = $_POST['harga'];
    
    $gbr = $_FILES['gbr']['name'];
    if (!empty($gbr)) {
        move_uploaded_file($_FILES['gbr']['tmp_name'], $path . $gbr);
    } else {
        $gbr = $result['gambar'];
    }

    $query = $conn->prepare("UPDATE tb_product SET nama_product = :namapro, deskripsi = :deskrip, harga = :harg, gambar = :gbar WHERE id_product = :idpr");
    $query->bindParam(':idpr', $idp);
    $query->bindParam(':namapro', $nma);
    $query->bindParam(':deskrip', $desk);
    $query->bindParam(':harg', $hrga);
    $query->bindParam(':gbar', $gbr);

    if ($query->execute()) {
        header('Location: ?page=pro');
    } else { 
        echo "Gagal update produk.";
    }
}
?>
