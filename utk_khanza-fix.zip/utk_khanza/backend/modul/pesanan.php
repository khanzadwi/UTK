<?php
include '../lib/koneksi.php'; // koneksi ke database
?>

<div class="container mt-5">
  <h2 class="mb-5 text-center">Daftar Pesanan</h2>
  <div class="table-responsive">
    <table class="table table-bordered table-hover">
      <thead class="text-center align-middle table-primary">
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>Telepon</th>
          <th>Alamat</th>
          <th>Nama Produk</th>
          <th>Jumlah</th>
          <th>Total Harga</th>
          <th>Metode</th>
          <th>Status</th>
          <th>Tanggal</th>
        </tr>
      </thead>
      <tbody>

      
        <?php
        $no = 1;
        $stmt = $conn->prepare("SELECT * FROM tb_pesanan ORDER BY tanggal_pesan DESC");
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data as $row) :
        ?>
        <tr>
          <td><?= $no++ ?></td>
          <td><?= htmlspecialchars($row['nama_pemesan']) ?></td>
          <td><?= htmlspecialchars($row['telepon']) ?></td>
          <td><?= htmlspecialchars($row['alamat']) ?></td>
          <td><?= htmlspecialchars($row['produk']) ?></td>
          <td><?= $row['jumlah'] ?></td>
          <td>Rp <?= number_format($row['total_harga'], 0, ',', '.') ?></td>
          <td><?= htmlspecialchars($row['metode_pembayaran']) ?></td>
          <td>

    <input type="hidden" name="id" value="<?= $row['id'] ?>">
    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
      <option value="Menunggu" <?= $row['status'] == 'Menunggu' ? 'selected' : '' ?>>Menunggu</option>
      <option value="Diperoses" <?= $row['status'] == 'Diproses' ? 'selected' : '' ?>>Diproses</option>
      <option value="Dikirim" <?= $row['status'] == 'Dikirim' ? 'selected' : '' ?>>Dikirim</option>
      <option value="Selesai" <?= $row['status'] == 'Selesai' ? 'selected' : '' ?>>Selesai</option>
    </select>
  </form>
</td>
          <td><?= $row['tanggal_pesan'] ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
