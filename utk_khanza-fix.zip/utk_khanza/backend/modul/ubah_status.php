<?php
include '../lib/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id = $_POST['id'];
  $status = $_POST['status'];

  $stmt = $conn->prepare("UPDATE tb_pesanan SET status = :status WHERE id_pesanan = :id");
  $stmt->execute([
    ':status' => $status,
    ':id' => $id
  ]);

  header("Location: ?page=pesanan");
  exit;
}
?>