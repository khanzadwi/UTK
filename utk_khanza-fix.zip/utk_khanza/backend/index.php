<?php 
        include"../lib/koneksi.php";
        session_start();
  if (!isset($_SESSION['admin'])) {
    header("location: lomin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="asset/css/backend.css">
</head>
<body>

<div class="sidebar">
<?php 
        include"modul/sidebar.php";
?>
</div>
<div class="content">
<?php 
$page = isset($_GET['page'])?$_GET['page']:"";
switch ($page) {
case 'con':
    include "modul/content.php";
    break;
case 'pro':
  include "modul/product/data.php";
  break;
case 'addpro':
  include "modul/product/add.php";
  break;
case 'delpro':
  include "modul/product/delpro.php";
  break;
case 'edpro':
  include "modul/product/editpro.php";
  break;
case 'peser':
  include "modul/peser.php";
  break;
case 'pesanan':
  include "modul/pesanan.php";
  break;
case 'ubahstatus':
  include "modul/ubah_status.php";
  break;
case 'user':
  include "modul/pengguna.php";
  break;
case 'logout':
  include "logout.php";
  break;

default:
case 'con':
    include "modul/content.php";
    break;
  break;
}
?>
</div>
  

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
